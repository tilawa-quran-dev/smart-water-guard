package com.watertank.app

import android.Manifest
import android.app.Activity
import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt3.Mqtt3AsyncClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt
import kotlin.random.Random

// =====================================================================
//  النماذج (Model)
// =====================================================================

data class Reading(
    val time: Long,
    val levelRaw: Double?,    // القراءة الخام لحساس المستوى (كما يرسلها الجهاز)
    val qualityRaw: Double?,  // القراءة الخام لحساس الجودة
    val simulated: Boolean,   // true = بيانات تجريبية
)

/** نقطتا معايرة لكل حساس. لا نفترض أي نوع حساس: أي حساس خطي يمكن معايرته بنقطتين. */
data class Calibration(
    val levelEmpty: Double? = null,   // القراءة الخام عندما يكون الخزان فارغاً
    val levelFull: Double? = null,    // القراءة الخام عندما يكون ممتلئاً
    val qualityBad: Double? = null,   // القراءة الخام الموافقة لأسوأ جودة (مؤشر 0)
    val qualityGood: Double? = null,  // القراءة الخام الموافقة لأفضل جودة (مؤشر 100)
)

data class DeviceSettings(
    val demoMode: Boolean = true,
    val simulateOffline: Boolean = false,
    val tankId: String = "tank1",
    val levelSensorType: String = "",
    val qualitySensorType: String = "",
    val levelUnit: String = "",
    val qualityUnit: String = "",
    val cal: Calibration = Calibration(),
    val alertsEnabled: Boolean = true,
    val lowLevelAlert: Int = 20,
    val lowQualityAlert: Int = 40,
    val staleAfterSec: Int = 30,
    val mqttHost: String = "",
    val mqttPort: Int = 8883,
    val mqttUser: String = "",
    val mqttPass: String = "",
    val mqttPrefix: String = "tanks",
)

enum class Link { OFF, CONNECTING, CONNECTED, ERROR }
data class ConnInfo(val link: Link = Link.OFF, val deviceOffline: Boolean = false, val msg: String = "")

val DEMO_CAL = Calibration(0.0, 1000.0, 0.0, 1000.0)

fun mapPercent(raw: Double?, a: Double?, b: Double?): Int? {
    if (raw == null || a == null || b == null || a == b) return null
    return (((raw - a) / (b - a)) * 100.0).coerceIn(0.0, 100.0).roundToInt()
}

data class UiState(
    val settings: DeviceSettings,
    val last: Reading?,
    val history: List<Reading>,
    val now: Long,
    val conn: ConnInfo = ConnInfo(),
) {
    val cal: Calibration get() = if (settings.demoMode) DEMO_CAL else settings.cal
    val levelPct: Int? get() = mapPercent(last?.levelRaw, cal.levelEmpty, cal.levelFull)
    val qualityIdx: Int? get() = mapPercent(last?.qualityRaw, cal.qualityBad, cal.qualityGood)
    val online: Boolean
        get() {
            val l = last ?: return false
            return !settings.simulateOffline && !conn.deviceOffline && now - l.time <= settings.staleAfterSec * 1000L
        }
}

// =====================================================================
//  أدوات مساعدة
// =====================================================================

fun fmt(d: Double): String =
    if (d == d.toLong().toDouble()) d.toLong().toString() else String.format(Locale.US, "%.1f", d)

fun fmtTime(t: Long): String = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.US).format(Date(t))

fun ago(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return when {
        s < 60 -> "قبل $s ثانية"
        s < 3600 -> "قبل ${s / 60} دقيقة"
        else -> "قبل ${s / 3600} ساعة"
    }
}

// =====================================================================
//  المساعد الصوتي: فهم السؤال وتكوين الجواب
// =====================================================================

fun norm(s: String): String = s
    .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    .replace('ى', 'ي').replace('ئ', 'ي').replace('ؤ', 'و').replace('ة', 'ه')

fun has(q: String, vararg keys: String): Boolean = keys.any { q.contains(norm(it)) }

fun answer(text: String, st: UiState): String {
    val q = norm(text)
    val last = st.last
    val demo = if (st.settings.demoMode) "تنبيه: هذه بيانات تجريبية وليست قراءات حقيقية. " else ""
    val age = if (last != null) ago(st.now - last.time) else ""
    val stale = if (last != null && !st.online)
        "الجهاز غير متصل، وهذه قراءة قديمة وليست مباشرة، آخر تحديث $age. " else ""

    fun levelT(): String {
        val p = st.levelPct
        val lr = last?.levelRaw
        return when {
            p != null -> "نسبة الماء في الخزان $p بالمئة"
            lr != null -> "حساس المستوى لم تتم معايرته بعد، لذلك لا أستطيع حساب النسبة. القراءة الخام ${fmt(lr)} ${st.settings.levelUnit}"
            else -> "لا توجد قراءة لمستوى الماء"
        }
    }

    fun qualityT(): String {
        val i = st.qualityIdx
        val qr = last?.qualityRaw
        return when {
            i != null -> "مؤشر جودة المياه $i من مئة حسب معايرتك، وهو ليس حكماً بصلاحية المياه للشرب"
            qr != null -> "حساس الجودة لم تتم معايرته بعد، لذلك لا أستطيع تقييم الجودة. القراءة الخام ${fmt(qr)} ${st.settings.qualityUnit}"
            else -> "لا توجد قراءة لجودة المياه"
        }
    }

    return when {
        has(q, "متصل", "اتصال", "الجهاز") -> when {
            st.settings.demoMode -> "لا يوجد جهاز حقيقي مربوط بعد، والاتصال الظاهر محاكاة. "
            st.conn.link != Link.CONNECTED -> "التطبيق غير متصل بالخادم حالياً. تحقق من إعدادات الاتصال. "
            last == null -> "لم يصل أي بيان من الجهاز حتى الآن. "
            st.online -> "نعم، الجهاز متصل، وآخر تحديث $age. "
            else -> "لا، الجهاز غير متصل. آخر قراءة وصلت $age. "
        }.let { demo + it }
        last == null -> "لم تصل أي قراءة بعد."
        has(q, "آخر قراءة") -> demo + stale + levelT() + ". " + qualityT()
        has(q, "نقاء", "جودة", "نظيف", "صلاحية") -> demo + stale + qualityT()
        has(q, "ممتلئ", "فاضي", "فارغ", "مليان") -> {
            val p = st.levelPct
            demo + stale + when {
                p == null -> levelT()
                p >= 95 -> "نعم، الخزان ممتلئ تقريباً، النسبة $p بالمئة"
                else -> "لا، الخزان غير ممتلئ، النسبة $p بالمئة"
            }
        }
        has(q, "حالة") -> demo + stale + levelT() + ". " + qualityT()
        has(q, "نسبة", "كم", "مستوى", "ماء", "مياه") -> demo + stale + levelT()
        else -> "لم أفهم السؤال. جرّب مثلاً: كم نسبة الماء في الخزان؟"
    }
}

// =====================================================================
//  التخزين (إعدادات ومعايرة)
// =====================================================================

fun loadSettings(p: SharedPreferences) = DeviceSettings(
    demoMode = p.getBoolean("demo", true),
    tankId = p.getString("tank", "tank1") ?: "tank1",
    levelSensorType = p.getString("lst", "") ?: "",
    qualitySensorType = p.getString("qst", "") ?: "",
    levelUnit = p.getString("lu", "") ?: "",
    qualityUnit = p.getString("qu", "") ?: "",
    cal = Calibration(
        p.getString("c1", null)?.toDoubleOrNull(),
        p.getString("c2", null)?.toDoubleOrNull(),
        p.getString("c3", null)?.toDoubleOrNull(),
        p.getString("c4", null)?.toDoubleOrNull(),
    ),
    alertsEnabled = p.getBoolean("ae", true),
    lowLevelAlert = p.getInt("la", 20),
    lowQualityAlert = p.getInt("qa", 40),
    staleAfterSec = p.getInt("st", 30),
    mqttHost = p.getString("mh", "") ?: "",
    mqttPort = p.getInt("mp", 8883),
    mqttUser = p.getString("mu", "") ?: "",
    mqttPass = p.getString("mw", "") ?: "",
    mqttPrefix = p.getString("mx", "tanks") ?: "tanks",
)

fun SharedPreferences.Editor.putD(k: String, v: Double?): SharedPreferences.Editor =
    if (v == null) remove(k) else putString(k, v.toString())

fun saveSettings(p: SharedPreferences, s: DeviceSettings) {
    p.edit()
        .putBoolean("demo", s.demoMode)
        .putString("tank", s.tankId)
        .putString("lst", s.levelSensorType)
        .putString("qst", s.qualitySensorType)
        .putString("lu", s.levelUnit)
        .putString("qu", s.qualityUnit)
        .putD("c1", s.cal.levelEmpty)
        .putD("c2", s.cal.levelFull)
        .putD("c3", s.cal.qualityBad)
        .putD("c4", s.cal.qualityGood)
        .putBoolean("ae", s.alertsEnabled)
        .putInt("la", s.lowLevelAlert)
        .putInt("qa", s.lowQualityAlert)
        .putInt("st", s.staleAfterSec)
        .putString("mh", s.mqttHost)
        .putInt("mp", s.mqttPort)
        .putString("mu", s.mqttUser)
        .putString("mw", s.mqttPass)
        .putString("mx", s.mqttPrefix)
        .apply()
}

// =====================================================================
//  ViewModel: مصدر البيانات (تجريبي الآن، وسيُستبدل بـ MQTT لاحقاً)
// =====================================================================

class TankViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", 0)
    private val _settings = MutableStateFlow(loadSettings(prefs))
    private val _last = MutableStateFlow<Reading?>(null)
    private val _history = MutableStateFlow<List<Reading>>(emptyList())
    private val _now = MutableStateFlow(System.currentTimeMillis())
    private val _conn = MutableStateFlow(ConnInfo())
    private var client: Mqtt3AsyncClient? = null
    private var connectedOnce = false

    val alerts = MutableStateFlow<List<String>>(emptyList())
    val heard = MutableStateFlow("")
    val reply = MutableStateFlow("")

    val state: StateFlow<UiState> =
        combine(_settings, _last, _history, _now, _conn) { s, l, h, n, c -> UiState(s, l, h, n, c) }
            .stateIn(viewModelScope, SharingStarted.Eagerly,
                UiState(_settings.value, null, emptyList(), _now.value, _conn.value))

    private var lastLowLevelAlert = 0L
    private var lastLowQualityAlert = 0L

    init {
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "تنبيهات الخزان", NotificationManager.IMPORTANCE_HIGH))

        viewModelScope.launch {
            while (true) { delay(1000); _now.value = System.currentTimeMillis() }
        }
        if (!_settings.value.demoMode) applyConnection()
        // مولّد بيانات تجريبية (يعمل فقط في الوضع التجريبي)
        viewModelScope.launch {
            var lvl = 640.0
            var q = 720.0
            while (true) {
                delay(3000)
                val s = _settings.value
                if (!s.demoMode || s.simulateOffline) continue
                lvl += Random.nextDouble(-30.0, 15.0)
                if (lvl < 40.0) lvl = 900.0
                lvl = lvl.coerceAtMost(1000.0)
                q = (q + Random.nextDouble(-15.0, 15.0)).coerceIn(0.0, 1000.0)
                push(Reading(System.currentTimeMillis(), lvl, q, simulated = true))
            }
        }
    }

    /** نقطة الدخول للقراءات الحقيقية (ستستدعيها طبقة MQTT في المرحلة التالية). */
    fun receiveReal(levelRaw: Double?, qualityRaw: Double?, test: Boolean = false) {
        push(Reading(System.currentTimeMillis(), levelRaw, qualityRaw, simulated = test))
    }

    // ---------- الاتصال بالجهاز عبر MQTT ----------

    fun setDemo(on: Boolean) {
        update { it.copy(demoMode = on, simulateOffline = false) }
        _last.value = null
        _history.value = emptyList()
        if (on) { disconnect(); _conn.value = ConnInfo() } else applyConnection()
    }

    private fun disconnect() {
        try { client?.disconnect() } catch (e: Exception) { }
        client = null
        connectedOnce = false
    }

    fun applyConnection() {
        disconnect()
        val s = _settings.value
        if (s.demoMode) { _conn.value = ConnInfo(); return }
        if (s.mqttHost.isBlank()) {
            _conn.value = ConnInfo(Link.ERROR, msg = "أدخل عنوان الخادم أولاً")
            return
        }
        _conn.value = ConnInfo(Link.CONNECTING)
        try {
            val c = MqttClient.builder()
                .useMqttVersion3()
                .identifier("watertank-" + UUID.randomUUID().toString().take(8))
                .serverHost(s.mqttHost.trim())
                .serverPort(s.mqttPort)
                .sslWithDefaultConfig()
                .automaticReconnectWithDefaultConfig()
                .addConnectedListener {
                    _conn.value = _conn.value.copy(link = Link.CONNECTED, msg = "")
                    if (connectedOnce) client?.let { cl -> subscribeAll(cl) }
                }
                .addDisconnectedListener {
                    if (client != null) _conn.value = _conn.value.copy(link = Link.CONNECTING)
                }
                .buildAsync()
            client = c
            val b = c.connectWith().keepAlive(30)
            val req = if (s.mqttUser.isNotBlank())
                b.simpleAuth().username(s.mqttUser.trim()).password(s.mqttPass.toByteArray()).applySimpleAuth()
            else b
            req.send().whenComplete { _, err ->
                if (err != null) {
                    _conn.value = ConnInfo(Link.ERROR, msg = "تعذر الاتصال: ${err.message ?: "خطأ غير معروف"}")
                } else {
                    connectedOnce = true
                    subscribeAll(c)
                }
            }
        } catch (e: Exception) {
            _conn.value = ConnInfo(Link.ERROR, msg = "إعدادات غير صحيحة: ${e.message}")
        }
    }

    private fun subscribeAll(c: Mqtt3AsyncClient) {
        val s = _settings.value
        val base = "${s.mqttPrefix.trim()}/${s.tankId.trim()}"
        c.subscribeWith().topicFilter("$base/data")
            .callback { p -> onData(String(p.payloadAsBytes)) }
            .send()
        c.subscribeWith().topicFilter("$base/status")
            .callback { p -> onStatus(String(p.payloadAsBytes)) }
            .send()
    }

    private fun onData(text: String) {
        try {
            val j = JSONObject(text)
            val lv = if (j.has("level") && !j.isNull("level")) j.getDouble("level") else null
            val qv = if (j.has("quality") && !j.isNull("quality")) j.getDouble("quality") else null
            if (lv == null && qv == null) return
            _conn.value = _conn.value.copy(deviceOffline = false)
            receiveReal(lv, qv, j.optBoolean("test", false))
        } catch (e: Exception) { }
    }

    private fun onStatus(text: String) {
        _conn.value = _conn.value.copy(deviceOffline = text.trim().lowercase() == "offline")
    }

    private fun push(r: Reading) {
        _last.value = r
        _history.value = (_history.value + r).takeLast(300)
        checkAlerts(r)
    }

    private fun checkAlerts(r: Reading) {
        val s = _settings.value
        if (!s.alertsEnabled) return
        val st = UiState(s, r, emptyList(), r.time)
        val tag = if (r.simulated) " (بيانات تجريبية)" else ""
        val p = st.levelPct
        if (p != null && p <= s.lowLevelAlert && r.time - lastLowLevelAlert > 300_000) {
            lastLowLevelAlert = r.time
            notify(1, "انخفاض مستوى المياه", "نسبة الماء $p بالمئة$tag", r.time)
        }
        val qi = st.qualityIdx
        if (qi != null && qi <= s.lowQualityAlert && r.time - lastLowQualityAlert > 300_000) {
            lastLowQualityAlert = r.time
            notify(2, "انخفاض مؤشر جودة المياه", "المؤشر $qi من مئة$tag", r.time)
        }
    }

    private fun notify(id: Int, title: String, text: String, time: Long) {
        alerts.value = (listOf("${fmtTime(time)} — $title: $text") + alerts.value).take(50)
        val ctx = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    fun update(f: (DeviceSettings) -> DeviceSettings) {
        val n = f(_settings.value)
        _settings.value = n
        saveSettings(prefs, n)
    }

    fun ask(text: String): String {
        val r = answer(text, state.value)
        heard.value = text
        reply.value = r
        return r
    }

    fun setReply(t: String) { reply.value = t }

    companion object { const val CH = "tank_alerts" }
}

// =====================================================================
//  الواجهة
// =====================================================================

val Aqua = Color(0xFF00B4D8)
val Navy = Color(0xFF0A2540)
val PaleAqua = Color(0xFFE3F4FA)
val Light = Color(0xFFF2F9FC)
val Warn = Color(0xFFFFF3CD)

@Composable
fun AppTheme(content: @Composable () -> Unit) =
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Aqua, background = Light),
        content = content,
    )

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth(),
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun Notice(text: String, color: Color = Warn) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(color).padding(12.dp)) {
        Text(text, color = Navy, fontSize = 14.sp)
    }
}

@Composable
fun TankGauge(pct: Int?, modifier: Modifier = Modifier) {
    Box(modifier.width(150.dp).height(190.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = CornerRadius(28.dp.toPx())
            drawRoundRect(PaleAqua, size = size, cornerRadius = r)
            if (pct != null) {
                val h = size.height * pct / 100f
                val clip = Path().apply {
                    addRoundRect(RoundRect(0f, 0f, size.width, size.height, r))
                }
                clipPath(clip) {
                    drawRect(Aqua, topLeft = Offset(0f, size.height - h), size = Size(size.width, h))
                }
            }
            drawRoundRect(Navy, size = size, cornerRadius = r, style = Stroke(4.dp.toPx()))
        }
        Text(if (pct != null) "$pct%" else "—", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Navy)
    }
}

@Composable
fun LineChart(values: List<Int?>, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        for (g in listOf(0f, 0.5f, 1f)) {
            drawLine(Color(0xFFCFE6EE), Offset(0f, size.height * g), Offset(size.width, size.height * g), 1.dp.toPx())
        }
        val pts = values.mapIndexedNotNull { i, v ->
            if (v == null) null
            else Offset(
                if (values.size < 2) 0f else size.width * i / (values.size - 1),
                size.height * (1f - v / 100f),
            )
        }
        for (i in 1 until pts.size) drawLine(color, pts[i - 1], pts[i], 3.dp.toPx())
    }
}

@Composable
fun App(vm: TankViewModel, speak: (String) -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val items = listOf("الرئيسية" to Icons.Default.Home, "السجل" to Icons.Default.Menu, "الإعدادات" to Icons.Default.Settings)
    Scaffold(
        containerColor = Light,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                items.forEachIndexed { i, (t, ic) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(ic, t) },
                        label = { Text(t) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(s, vm, speak)
                1 -> HistoryScreen(s, vm)
                else -> SettingsScreen(s, vm)
            }
        }
    }
}

val QUICK_QUESTIONS = listOf(
    "كم نسبة الماء في الخزان؟",
    "ما نسبة نقاء المياه؟",
    "هل الخزان ممتلئ؟",
    "أعطني حالة الخزان",
    "هل الجهاز متصل؟",
    "أعطني آخر قراءة للمياه",
)

@Composable
fun HomeScreen(s: UiState, vm: TankViewModel, speak: (String) -> Unit) {
    val reply by vm.reply.collectAsStateWithLifecycle()
    val heard by vm.heard.collectAsStateWithLifecycle()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && text != null) speak(vm.ask(text))
    }
    val last = s.last
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("مراقب خزان المياه", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        if (s.settings.demoMode) Notice("وضع تجريبي: كل الأرقام هنا بيانات تجريبية وليست قراءات حقيقية من الجهاز.")

        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val c = s.conn
                val dot = when {
                    s.settings.demoMode -> Color(0xFFF9A825)
                    s.online -> Color(0xFF2E7D32)
                    c.link == Link.CONNECTED || c.link == Link.CONNECTING -> Color(0xFFF9A825)
                    else -> Color(0xFFC62828)
                }
                Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
                Text(
                    when {
                        s.settings.demoMode && s.online -> "  جهاز تجريبي (محاكاة) — لا يوجد جهاز حقيقي"
                        s.settings.demoMode -> "  انقطاع الجهاز (محاكاة)"
                        c.link == Link.ERROR -> "  تعذر الاتصال بالخادم"
                        c.link == Link.CONNECTING -> "  جارٍ الاتصال بالخادم..."
                        c.link == Link.OFF -> "  غير متصل بالخادم"
                        s.online -> "  الجهاز متصل"
                        last == null -> "  متصل بالخادم، بانتظار أول قراءة من الجهاز"
                        else -> "  الجهاز غير متصل"
                    },
                    fontWeight = FontWeight.Bold, color = Navy,
                )
            }
            if (!s.settings.demoMode && s.conn.msg.isNotEmpty()) {
                Text(s.conn.msg, fontSize = 13.sp, color = Color(0xFFC62828))
            }
            Text(
                if (last != null) "آخر تحديث: ${fmtTime(last.time)} (${ago(s.now - last.time)})" else "لم يصل أي بيان بعد",
                fontSize = 13.sp, color = Color.Gray,
            )
        }
        if (!s.settings.demoMode && last?.simulated == true) Notice("هذه القراءة من وضع الاختبار في الجهاز وليست من حساس حقيقي.")
        if (last != null && !s.online) Notice("الجهاز غير متصل. القراءات أدناه قديمة وليست مباشرة.")

        Panel {
            Text("مستوى الماء", fontWeight = FontWeight.Bold, color = Navy)
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                TankGauge(s.levelPct)
            }
            val lr = last?.levelRaw
            if (s.levelPct == null) {
                Text("حساس المستوى غير معاير بعد، لذلك لا تُعرض النسبة." +
                    (if (lr != null) " القراءة الخام: ${fmt(lr)} ${s.settings.levelUnit}" else ""),
                    fontSize = 14.sp)
            }
        }

        Panel {
            Text("جودة المياه", fontWeight = FontWeight.Bold, color = Navy)
            val qi = s.qualityIdx
            val qr = last?.qualityRaw
            if (qi != null) {
                Text("مؤشر الجودة: $qi من 100", fontSize = 20.sp, color = Navy)
                LinearProgressIndicator(progress = { qi / 100f }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Aqua)
                Text("هذا مؤشر حسب معايرتك، وليس حكماً بصلاحية المياه للشرب.", fontSize = 12.sp, color = Color.Gray)
            } else {
                Text("حساس الجودة غير معاير. لا يُعرض تقييم للجودة ولا حكم بصلاحية الشرب قبل تحديد الحساس ومعايرته." +
                    (if (qr != null) " القراءة الخام: ${fmt(qr)} ${s.settings.qualityUnit}" else ""),
                    fontSize = 14.sp)
            }
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Button(
                onClick = {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                        .putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدّث الآن")
                    try { launcher.launch(i) } catch (e: ActivityNotFoundException) {
                        vm.setReply("خدمة التعرف على الصوت غير متوفرة على هذا الهاتف. استخدم الأسئلة الجاهزة أدناه.")
                    }
                },
                modifier = Modifier.size(96.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Aqua),
                contentPadding = PaddingValues(0.dp),
            ) { Text("🎤", fontSize = 40.sp) }
        }
        Text("اضغط على الميكروفون واسأل", Modifier.fillMaxWidth(), color = Color.Gray, fontSize = 13.sp)

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(QUICK_QUESTIONS) { q ->
                AssistChip(onClick = { speak(vm.ask(q)) }, label = { Text(q) })
            }
        }
        if (reply.isNotEmpty()) Panel {
            if (heard.isNotEmpty()) Text("سؤالك: $heard", fontSize = 13.sp, color = Color.Gray)
            Text(reply, fontSize = 17.sp, color = Navy)
        }
    }
}

@Composable
fun HistoryScreen(s: UiState, vm: TankViewModel) {
    val alerts by vm.alerts.collectAsStateWithLifecycle()
    val rows = s.history.takeLast(100).reversed()
    val lv = s.history.takeLast(60).map { mapPercent(it.levelRaw, s.cal.levelEmpty, s.cal.levelFull) }
    val qv = s.history.takeLast(60).map { mapPercent(it.qualityRaw, s.cal.qualityBad, s.cal.qualityGood) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Panel {
                Text("تغيّر مستوى الماء (%)", fontWeight = FontWeight.Bold, color = Navy)
                if (lv.any { it != null }) LineChart(lv, Aqua) else Text("يظهر الرسم بعد معايرة حساس المستوى.")
            }
        }
        item {
            Panel {
                Text("تغيّر مؤشر الجودة", fontWeight = FontWeight.Bold, color = Navy)
                if (qv.any { it != null }) LineChart(qv, Navy) else Text("يظهر الرسم بعد معايرة حساس الجودة.")
            }
        }
        item { Text("التنبيهات", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy) }
        if (alerts.isEmpty()) item { Text("لا توجد تنبيهات.", color = Color.Gray) }
        items(alerts) { Notice(it) }
        item { Text("سجل القراءات", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy) }
        if (rows.isEmpty()) item { Text("لا توجد قراءات بعد.", color = Color.Gray) }
        items(rows) { r ->
            val p = mapPercent(r.levelRaw, s.cal.levelEmpty, s.cal.levelFull)
            Panel {
                Text(fmtTime(r.time) + if (r.simulated) "  (تجريبية)" else "", fontSize = 13.sp, color = Color.Gray)
                Text(
                    "مستوى: " + (if (p != null) "$p%" else "غير معاير") +
                        "  |  خام: ${r.levelRaw?.let { fmt(it) } ?: "-"} / ${r.qualityRaw?.let { fmt(it) } ?: "-"}",
                    fontSize = 14.sp,
                )
            }
        }
    }
}

@Composable
fun TextRow(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    var text by remember { mutableStateOf(value) }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it; onChange(it) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
fun NumRow(label: String, value: Double?, version: Int, onChange: (Double?) -> Unit) {
    var text by remember(version) { mutableStateOf(value?.let { fmt(it) } ?: "") }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it; onChange(it.toDoubleOrNull()) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Navy)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(s: UiState, vm: TankViewModel) {
    val st = s.settings
    var ver by remember { mutableIntStateOf(0) }
    val canUseLast = s.last?.simulated == false
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("الإعدادات", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)

        Panel {
            Text("وضع البيانات", fontWeight = FontWeight.Bold, color = Navy)
            SwitchRow("وضع البيانات التجريبية", st.demoMode) { v -> vm.setDemo(v) }
            Text("في الوضع التجريبي تُستخدم معايرة افتراضية (0 إلى 1000) وبيانات مولّدة. أوقفه عند ربط الجهاز الحقيقي.", fontSize = 12.sp, color = Color.Gray)
            if (st.demoMode) SwitchRow("محاكاة انقطاع الجهاز", st.simulateOffline) { v -> vm.update { it.copy(simulateOffline = v) } }
        }

        Panel {
            Text("الجهاز", fontWeight = FontWeight.Bold, color = Navy)
            TextRow("معرّف الخزان", st.tankId) { v -> vm.update { it.copy(tankId = v) } }
            NumRow("اعتبر الجهاز غير متصل بعد (ثانية)", st.staleAfterSec.toDouble(), ver) { v ->
                if (v != null && v >= 5) vm.update { it.copy(staleAfterSec = v.toInt()) }
            }
        }

        Panel {
            Text("الاتصال بالجهاز (MQTT)", fontWeight = FontWeight.Bold, color = Navy)
            Text("املأ بيانات الخادم، ثم أوقف الوضع التجريبي واضغط «حفظ والاتصال». الاتصال مشفّر (TLS).", fontSize = 12.sp, color = Color.Gray)
            TextRow("عنوان الخادم (Host)", st.mqttHost) { v -> vm.update { it.copy(mqttHost = v.trim()) } }
            NumRow("المنفذ (Port) — عادةً 8883", st.mqttPort.toDouble(), ver) { v ->
                if (v != null && v >= 1) vm.update { it.copy(mqttPort = v.toInt()) }
            }
            TextRow("اسم المستخدم", st.mqttUser) { v -> vm.update { it.copy(mqttUser = v.trim()) } }
            TextRow("كلمة المرور", st.mqttPass, secret = true) { v -> vm.update { it.copy(mqttPass = v) } }
            TextRow("بادئة المواضيع", st.mqttPrefix) { v -> vm.update { it.copy(mqttPrefix = v.trim()) } }
            Text("الجهاز يرسل قراءاته إلى: ${st.mqttPrefix}/${st.tankId}/data", fontSize = 12.sp, color = Color.Gray)
            Text(
                when (s.conn.link) {
                    Link.OFF -> "الحالة: غير متصل بالخادم"
                    Link.CONNECTING -> "الحالة: جارٍ الاتصال..."
                    Link.CONNECTED -> "الحالة: متصل بالخادم"
                    Link.ERROR -> "الحالة: " + s.conn.msg
                },
                color = Navy,
            )
            Button(
                enabled = !st.demoMode,
                onClick = { vm.applyConnection() },
            ) { Text("حفظ والاتصال") }
            if (st.demoMode) Text("أوقف «وضع البيانات التجريبية» أعلاه لتفعيل الاتصال.", fontSize = 12.sp, color = Color.Gray)
        }

        Panel {
            Text("حساس مستوى الماء", fontWeight = FontWeight.Bold, color = Navy)
            Text("نوع الحساس غير محدد افتراضياً. اكتب نوعه عند معرفته (للتوثيق فقط).", fontSize = 12.sp, color = Color.Gray)
            TextRow("نوع الحساس", st.levelSensorType) { v -> vm.update { it.copy(levelSensorType = v) } }
            TextRow("وحدة القراءة الخام (مثل cm أو V)", st.levelUnit) { v -> vm.update { it.copy(levelUnit = v) } }
            NumRow("القراءة الخام عند الخزان فارغ", st.cal.levelEmpty, ver) { v -> vm.update { it.copy(cal = it.cal.copy(levelEmpty = v)) } }
            NumRow("القراءة الخام عند الخزان ممتلئ", st.cal.levelFull, ver) { v -> vm.update { it.copy(cal = it.cal.copy(levelFull = v)) } }
            OutlinedButton(enabled = canUseLast, onClick = {
                s.last?.levelRaw?.let { x -> vm.update { it.copy(cal = it.cal.copy(levelEmpty = x)) }; ver++ }
            }) { Text("اعتمد القراءة الحالية كـ «فارغ»") }
            OutlinedButton(enabled = canUseLast, onClick = {
                s.last?.levelRaw?.let { x -> vm.update { it.copy(cal = it.cal.copy(levelFull = x)) }; ver++ }
            }) { Text("اعتمد القراءة الحالية كـ «ممتلئ»") }
        }

        Panel {
            Text("حساس جودة المياه", fontWeight = FontWeight.Bold, color = Navy)
            Text("لا يُعرض أي مؤشر جودة قبل إدخال نقطتي المعايرة من مواصفات الحساس. المؤشر لا يعني صلاحية الشرب.", fontSize = 12.sp, color = Color.Gray)
            TextRow("نوع الحساس", st.qualitySensorType) { v -> vm.update { it.copy(qualitySensorType = v) } }
            TextRow("وحدة القراءة الخام (مثل ppm أو NTU)", st.qualityUnit) { v -> vm.update { it.copy(qualityUnit = v) } }
            NumRow("القراءة الخام الموافقة لأسوأ جودة (مؤشر 0)", st.cal.qualityBad, ver) { v -> vm.update { it.copy(cal = it.cal.copy(qualityBad = v)) } }
            NumRow("القراءة الخام الموافقة لأفضل جودة (مؤشر 100)", st.cal.qualityGood, ver) { v -> vm.update { it.copy(cal = it.cal.copy(qualityGood = v)) } }
        }

        Panel {
            Text("التنبيهات", fontWeight = FontWeight.Bold, color = Navy)
            SwitchRow("تفعيل التنبيهات", st.alertsEnabled) { v -> vm.update { it.copy(alertsEnabled = v) } }
            Text("تنبيه عند انخفاض الماء إلى ${st.lowLevelAlert}%")
            Slider(
                value = st.lowLevelAlert.toFloat(),
                onValueChange = { f -> vm.update { it.copy(lowLevelAlert = f.roundToInt()) } },
                valueRange = 5f..50f,
            )
            Text("تنبيه عند انخفاض مؤشر الجودة إلى ${st.lowQualityAlert} (بعد المعايرة فقط)")
            Slider(
                value = st.lowQualityAlert.toFloat(),
                onValueChange = { f -> vm.update { it.copy(lowQualityAlert = f.roundToInt()) } },
                valueRange = 5f..90f,
            )
        }
    }
}

// =====================================================================
//  النشاط الرئيسي + النطق الصوتي
// =====================================================================

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private val vm: TankViewModel by viewModels()
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
                    LaunchedEffect(Unit) {
                        if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    App(vm) { speak(it) }
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val r = tts?.setLanguage(Locale("ar"))
            ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun speak(t: String) {
        if (ttsOk) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
