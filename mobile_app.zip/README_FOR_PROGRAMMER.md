# 📱 تطبيق الموبايل: حارس المياه والآبار الذكي
### المبتكر: المهندس أنس القليصي (الصف الثامن) - صنعاء 2026

---

## 👨‍💻 مرحباً بك يا زميلنا المبرمج!
هذا الدليل أُعد خصيصاً لمساعدتك في تشغيل وبناء تطبيق الموبايل لمشروع أنس بكل سهولة.

---

## ⚙️ كيف يعمل الاتصال بين الهاتف والـ ESP32-S3؟
1. جهاز الـ ESP32-S3 يبث شبكة واي فاي محلية مستقلة تماماً (Offline SoftAP):
   - **اسم الشبكة (SSID):** `Water-Guard-Anas`
   - **كلمة المرور:** `12345678`
   - **عنوان السيرفر (IP):** `http://192.168.4.1`
2. بمجرد اتصال الهاتف بهذه الشبكة، يقوم التطبيق بإرسال طلبات **HTTP REST API** بصيغة **JSON**.

---

## 📡 واجهات الـ REST API المتوفرة في الـ ESP32:

### 1. جلب البيانات المباشرة (Live Status)
- **Method:** `GET`
- **URL:** `http://192.168.4.1/api/status`
- **Response (JSON):**
```json
{
  "liters": 4.15,
  "ml": 4150,
  "percentage": 83,
  "dist": 23.5,
  "dist_ok": true,
  "tds": 220,
  "tds_raw": 580,
  "tds_text": "ممتاز وصالح للشرب 🟢",
  "oled_ok": true,
  "pump": false,
  "relay_mode": "NC",
  "ai_status": "طبيعي (Normal)",
  "ai_conf": 0.98
}
```

### 2. تشغيل المضخة
- **Method:** `GET`
- **URL:** `http://192.168.4.1/api/pump/on`
- **Response:** `OK`

### 3. إيقاف المضخة
- **Method:** `GET`
- **URL:** `http://192.168.4.1/api/pump/off`
- **Response:** `OK`

### 4. تبديل وضع إشارة الريليه (NO / NC)
- **Method:** `GET`
- **URL:** `http://192.168.4.1/api/pump/toggle_mode`
- **Response:** `NO` أو `NC`

---

## 🚀 طريقة تشغيل تطبيق فلاتر (Flutter):
1. افتح المجلد `mobile_app` في محرر الأكواد (VS Code أو Android Studio).
2. شغل الأمر في التيرمنال:
   ```bash
   flutter pub get
   ```
3. اشبك هاتفك أو شغل المحاكي ثم اكتب:
   ```bash
   flutter run
   ```
4. لبناء ملف التطبيق بصيغة APK لتثبيته مباشرة على أي هاتف أندرويد:
   ```bash
   flutter build apk --release
   ```
   سيتم إنشاء ملف الـ APK في: `build/app/outputs/flutter-apk/app-release.apk`
