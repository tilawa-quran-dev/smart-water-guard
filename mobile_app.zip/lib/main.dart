import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const WaterGuardApp());
}

class WaterGuardApp extends StatelessWidget {
  const WaterGuardApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Water Smart Guard',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF070D1E),
        primaryColor: const Color(0xFF0284C7),
        cardColor: const Color(0xFF111A36),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // بيانات الحساسات والحالة الحية
  double liters = 0.0;
  double previousLiters = -1.0;
  int milliliters = 0;
  int percentage = 0;
  double distanceCm = 0.0;
  int tdsPpm = 0;
  String tdsText = "جاري الفحص...";
  bool pumpRunning = false;
  String relayMode = "NC";
  String aiStatus = "طبيعي (Normal)";
  bool isConnected = false;
  bool isCommandLoading = false;

  // ------------------- نظام تتبع استهلاك الماء الأسبوعي -------------------
  // استهلاك أيام الأسبوع باللترات: السبت، الأحد، الإثنين، الثلاثاء، الأربعاء، الخميس، الجمعة
  final List<String> weekDays = [
    "السبت",
    "الأحد",
    "الإثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة"
  ];
  List<double> dailyConsumption = [4.2, 5.0, 3.8, 4.6, 5.2, 4.0, 4.6]; // استهلاك الأيام
  int currentDayIndex = 6; // يوم الجمعة (اليوم الحالي افتراضياً)

  // ------------------- إعدادات الأمان (Security PIN) -------------------
  bool isSecurityPinEnabled = true;
  final String correctPin = "1234";

  Timer? _pollingTimer;
  final String espBaseUrl = "http://192.168.4.1";

  @override
  void initState() {
    super.initState();
    fetchStatus();
    _pollingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      fetchStatus();
    });
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }

  // حساب إجمالي الاستهلاك في الأسبوع الواحد
  double get totalWeeklyConsumption {
    return dailyConsumption.fold(0.0, (sum, val) => sum + val);
  }

  // حساب المعدل اليومي
  double get averageDailyConsumption {
    return totalWeeklyConsumption / dailyConsumption.length;
  }

  // جلب البيانات من الـ ESP32 وحساب الاستهلاك التراكمي
  Future<void> fetchStatus() async {
    try {
      final response = await http
          .get(Uri.parse('$espBaseUrl/api/status'))
          .timeout(const Duration(milliseconds: 1500));

      if (response.statusCode == 200) {
        final data = json.decode(utf8.decode(response.bodyBytes));
        double newLiters = (data['liters'] as num).toDouble();

        // حساب الاستهلاك الحقيقي: إذا نزل منسوب الماء في الخزان نجمع النقص إلى استهلاك اليوم
        if (previousLiters > 0 && newLiters < previousLiters) {
          double consumedNow = previousLiters - newLiters;
          if (consumedNow > 0.05 && consumedNow < 5.0) {
            setState(() {
              dailyConsumption[currentDayIndex] += consumedNow;
            });
          }
        }
        previousLiters = newLiters;

        setState(() {
          isConnected = true;
          liters = newLiters;
          milliliters = (data['ml'] as num).toInt();
          percentage = (data['percentage'] as num).toInt();
          distanceCm = (data['dist'] as num).toDouble();
          tdsPpm = (data['tds'] as num).toInt();
          tdsText = data['tds_text'] ?? "";
          pumpRunning = data['pump'] ?? false;
          relayMode = data['relay_mode'] ?? "NC";
          aiStatus = data['ai_status'] ?? "طبيعي";
        });
      } else {
        setState(() => isConnected = false);
      }
    } catch (e) {
      setState(() => isConnected = false);
    }
  }

  // طلب تشغيل أو إيقاف المضخة مع فحص الأمان (PIN Security)
  Future<void> handlePumpAction(bool start) async {
    if (start && isSecurityPinEnabled) {
      // إظهار نافذة إدخال رمز الأمان لحماية المضخة
      showPinDialog(onSuccess: () => executePumpCommand(true));
    } else {
      executePumpCommand(start);
    }
  }

  // إرسال الأمر للـ ESP32
  Future<void> executePumpCommand(bool start) async {
    setState(() => isCommandLoading = true);
    final endpoint = start ? '/api/pump/on' : '/api/pump/off';
    try {
      final res = await http.get(Uri.parse('$espBaseUrl$endpoint'));
      if (res.statusCode == 200) {
        setState(() => pumpRunning = start);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("⚠️ تأكد من الاتصال بشبكة الواي فاي: Water-Guard-Anas"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => isCommandLoading = false);
      fetchStatus();
    }
  }

  // نافذة التحقق الأمني من الرمز السري (Security Hardening)
  void showPinDialog({required VoidCallback onSuccess}) {
    final pinController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF111A36),
        title: const Row(
          children: [
            Icon(Icons.shield_rounded, color: Colors.amber),
            SizedBox(width: 8),
            Text("تأكيد أمان المحرك 🔒", style: TextStyle(fontSize: 16)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "أدخل الرمز السري المصرح به لتشغيل مضخة البئر:",
              style: TextStyle(fontSize: 13, color: Colors.white70),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              textAlign: TextAlign.center,
              maxLength: 4,
              style: const TextStyle(fontSize: 22, letterSpacing: 8, color: Colors.cyanAccent),
              decoration: InputDecoration(
                hintText: "••••",
                hintStyle: const TextStyle(color: Colors.white30),
                filled: true,
                fillColor: const Color(0xFF070D1E),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("إلغاء", style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            onPressed: () {
              if (pinController.text == correctPin) {
                Navigator.pop(ctx);
                onSuccess();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("❌ رمز الأمان غير صحيح! تم رفض التشغيل."),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF22C55E)),
            child: const Text("تأكيد وتشغيل", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // تبديل وضع الريليه
  Future<void> toggleRelayMode() async {
    try {
      final res = await http.get(Uri.parse('$espBaseUrl/api/pump/toggle_mode'));
      if (res.statusCode == 200) {
        setState(() => relayMode = res.body);
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  Color getTdsColor(int ppm) {
    if (ppm == 0) return Colors.grey;
    if (ppm < 350) return const Color(0xFF22C55E); // شرب
    if (ppm < 600) return const Color(0xFFEAB308); // منزلي
    if (ppm < 900) return const Color(0xFFF97316); // مالح
    return const Color(0xFFEF4444); // ملوث
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          children: [
            Text(
              "حارس المياه والآبار الذكي 🛡️",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            Text(
              "المبتكر: المهندس أنس القليصي",
              style: TextStyle(fontSize: 12, color: Colors.lightBlueAccent),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF0C152E),
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: Icon(
              isConnected ? Icons.wifi : Icons.wifi_off,
              color: isConnected ? Colors.greenAccent : Colors.redAccent,
              size: 26,
            ),
          ),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: RefreshIndicator(
          onRefresh: fetchStatus,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // تنبيه انقطاع الاتصال
                if (!isConnected)
                  Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.redAccent),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "غير متصل بالجهاز! اتصل بشبكة الواي فاي (Water-Guard-Anas) كلمة السر (12345678)",
                            style: TextStyle(fontSize: 12, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),

                // بطاقة الخزان الرسومية الحية
                _buildTankCard(),

                const SizedBox(height: 14),

                // 🌟 بطاقة إحصائيات استهلاك الماء الأسبوعي (الميزة الجديدة) 🌟
                _buildWeeklyConsumptionCard(),

                const SizedBox(height: 14),

                // بطاقة نقاوة وجودة الماء TDS
                _buildTdsCard(),

                const SizedBox(height: 14),

                // بطاقة التحكم بالمضخة والريليه
                _buildPumpControlCard(),

                const SizedBox(height: 14),

                // بطاقة الذكاء الاصطناعي الصوتي
                _buildAiCard(),

                const SizedBox(height: 16),
                const Text(
                  "صنعاء 2026 - مسابقة الابتكار الإقليمية",
                  style: TextStyle(fontSize: 11, color: Colors.white38),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ------------------- تصميم بطاقة استهلاك الماء الأسبوعي (Weekly Consumption) -------------------
  Widget _buildWeeklyConsumptionCard() {
    double maxDay = dailyConsumption.reduce((curr, next) => curr > next ? curr : next);
    if (maxDay == 0) maxDay = 1.0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF101B3B),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF38BDF8).withOpacity(0.4), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // العنوان والأيقونة
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.bar_chart_rounded, color: Color(0xFF38BDF8), size: 24),
                  SizedBox(width: 8),
                  Text(
                    "استهلاك الماء في الأسبوع الواحد 📊",
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.greenAccent),
                ),
                child: const Text(
                  "توفير ممتاز 💧",
                  style: TextStyle(fontSize: 11, color: Colors.greenAccent, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // الأرقام الإجمالية
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildMetricItem(
                label: "إجمالي استهلاك الأسبوع",
                value: "${totalWeeklyConsumption.toStringAsFixed(1)} لتر",
                color: const Color(0xFF38BDF8),
              ),
              Container(width: 1, height: 35, color: Colors.white12),
              _buildMetricItem(
                label: "المعدل اليومي",
                value: "${averageDailyConsumption.toStringAsFixed(1)} لتر/يوم",
                color: Colors.cyanAccent,
              ),
            ],
          ),

          const SizedBox(height: 16),
          const Text(
            "مخطط الاستهلاك اليومي على مدار الأسبوع (لتر):",
            style: TextStyle(fontSize: 12, color: Colors.white54),
          ),
          const SizedBox(height: 10),

          // الرسم البياني بالأعمدة (Bar Chart) لأيام الأسبوع السبعة
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF070D1E),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(weekDays.length, (index) {
                double val = dailyConsumption[index];
                double barHeight = (val / maxDay) * 65.0;
                bool isToday = (index == currentDayIndex);

                return Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    // رقم اللتر فوق العمود
                    Text(
                      val.toStringAsFixed(1),
                      style: TextStyle(
                        fontSize: 9,
                        color: isToday ? Colors.cyanAccent : Colors.white60,
                        fontWeight: isToday ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                    const SizedBox(height: 4),

                    // العمود الرسومي
                    Container(
                      width: 18,
                      height: barHeight > 10 ? barHeight : 10,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: isToday
                              ? [const Color(0xFF38BDF8), const Color(0xFF0284C7)]
                              : [Colors.blueGrey.shade400, Colors.blueGrey.shade700],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                        borderRadius: BorderRadius.circular(6),
                        border: isToday ? Border.all(color: Colors.cyanAccent, width: 1.2) : null,
                      ),
                    ),
                    const SizedBox(height: 6),

                    // اسم اليوم
                    Text(
                      weekDays[index],
                      style: TextStyle(
                        fontSize: 10,
                        color: isToday ? Colors.cyanAccent : Colors.white54,
                        fontWeight: isToday ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ],
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricItem({required String label, required String value, required Color color}) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.white54)),
        const SizedBox(height: 3),
        Text(
          value,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color),
        ),
      ],
    );
  }

  // بطاقة الخزان الرسومية
  Widget _buildTankCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF111A36),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF0284C7), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            "مستوى الماء في الخزان (دبة 5 لتر)",
            style: TextStyle(fontSize: 14, color: Colors.white70),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                width: 90,
                height: 130,
                decoration: BoxDecoration(
                  color: const Color(0xFF0A1128),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFF38BDF8), width: 3),
                ),
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 600),
                      width: double.infinity,
                      height: (percentage / 100.0) * 124,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF38BDF8), Color(0xFF0284C7)],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(12),
                          bottomRight: Radius.circular(12),
                        ),
                      ),
                    ),
                    Center(
                      child: Text(
                        "$percentage%",
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          shadows: [Shadow(blurRadius: 5, color: Colors.black)],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "${liters.toStringAsFixed(2)} لتر",
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF38BDF8),
                    ),
                  ),
                  Text(
                    "$milliliters مللتر",
                    style: const TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0C152E),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      distanceCm > 0 ? "المسافة: ${distanceCm.toStringAsFixed(1)} سم" : "المسافة: قريب جداً",
                      style: const TextStyle(fontSize: 12, color: Colors.lightBlueAccent),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  // بطاقة نقاوة الماء TDS
  Widget _buildTdsCard() {
    final statusColor = getTdsColor(tdsPpm);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF09233F),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: statusColor, width: 1.5),
      ),
      child: Column(
        children: [
          const Text(
            "نقاوة وجودة الماء (TDS Salinity)",
            style: TextStyle(fontSize: 14, color: Colors.white70),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "$tdsPpm",
                style: TextStyle(
                  fontSize: 34,
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                "PPM",
                style: TextStyle(fontSize: 16, color: Colors.white54),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: statusColor),
            ),
            child: Text(
              tdsText,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: statusColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // بطاقة التحكم بالمضخة
  Widget _buildPumpControlCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF111A36),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF1E293B)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "مضخة التعبئة (Pump Relay):",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: pumpRunning ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: pumpRunning ? Colors.green : Colors.red),
                ),
                child: Text(
                  pumpRunning ? "تعمل الآن 🟢" : "متوقفة 🔴",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: pumpRunning ? Colors.greenAccent : Colors.redAccent,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: isCommandLoading ? null : () => handlePumpAction(true),
                  icon: const Icon(Icons.play_arrow_rounded, color: Colors.black),
                  label: const Text("تشغيل المضخة", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF22C55E),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: isCommandLoading ? null : () => handlePumpAction(false),
                  icon: const Icon(Icons.stop_rounded, color: Colors.white),
                  label: const Text("إيقاف المضخة", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton.icon(
                onPressed: toggleRelayMode,
                icon: const Icon(Icons.swap_horiz, size: 18, color: Colors.white54),
                label: Text(
                  "نمط الإشارة: $relayMode",
                  style: const TextStyle(fontSize: 11, color: Colors.white54),
                ),
              ),
              Row(
                children: [
                  const Icon(Icons.lock_outline, size: 14, color: Colors.amber),
                  const SizedBox(width: 4),
                  const Text("قفل الأمان: ", style: TextStyle(fontSize: 11, color: Colors.white54)),
                  Switch(
                    value: isSecurityPinEnabled,
                    onChanged: (val) => setState(() => isSecurityPinEnabled = val),
                    activeColor: Colors.amber,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  // بطاقة الذكاء الاصطناعي
  Widget _buildAiCard() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0C152E),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF0284C7).withOpacity(0.5)),
      ),
      child: Row(
        children: [
          const Icon(Icons.graphic_eq_rounded, color: Color(0xFF38BDF8), size: 28),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "ذكاء اصطناعي صوتي (TinyML Acoustic Guard):",
                  style: TextStyle(fontSize: 11, color: Colors.white54),
                ),
                Text(
                  aiStatus,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF38BDF8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
